下载地址：http://mirrors.hust.edu.cn/apache/zookeeper/

Linux下载：

```
wget http://mirrors.hust.edu.cn/apache/zookeeper/zookeeper-3.5.3-beta/zookeeper-3.5.3-beta.tar.gz
```
解压：

```
tar -xvf zookeeper-3.5.3-beta.tar.gz 
```

这里提供一个免费的注册中心：


```
106.13.122.117:2181
```


Zookeeper 查看工具：

http://www.52itstyle.top/thread-37713-1-1.html