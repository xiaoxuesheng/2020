访问地址：https://maven.aliyun.com/mvn/view

配置：

```
<mirror>
       <id>nexus-aliyun</id>  
       <mirrorOf>central</mirrorOf>    
       <name>Nexus aliyun</name>  
       <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
</mirror>
```
