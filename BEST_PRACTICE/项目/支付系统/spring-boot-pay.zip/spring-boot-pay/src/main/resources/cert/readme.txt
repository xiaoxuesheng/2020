﻿微信支付证书存放路径地址(微信退款 需要证书认证)
apiclient_cert.p12
微信商户平台(pay.weixin.qq.com)-->账户中心-->账户设置-->API安全-->证书下载，使用apiclient_cert.p12即可