package com.itstyle.es.common.constant;

public class PageConstant {
	public static final Integer PAGE_SIZE = 10;          // 每页数量
	public static final  Integer DEFAULT_PAGE_NUMBER = 0; // 默认当前页码
}
